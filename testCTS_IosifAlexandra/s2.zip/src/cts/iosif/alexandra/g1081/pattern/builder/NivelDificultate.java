package cts.iosif.alexandra.g1081.pattern.builder;

public enum NivelDificultate {
    INCEPATOR,
    MEDIU,
    AVANSAT
}
