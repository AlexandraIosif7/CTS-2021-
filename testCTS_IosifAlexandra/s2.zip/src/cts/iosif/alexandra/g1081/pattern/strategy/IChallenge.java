package cts.iosif.alexandra.g1081.pattern.strategy;

public interface IChallenge {
    public void startExercitiu(int nrRepetitii);
}