package cts.iosif.alexandra.g1081.pattern.builder;

public interface AbstractBuilder {
    public CursDeFitness construieste();
}
